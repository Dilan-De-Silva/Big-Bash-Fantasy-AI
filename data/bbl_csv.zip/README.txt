All Big Bash League match data in CSV format
============================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the IPL data from YAML into this CSV format. This then expanded
to include international T20s, for both women and men, before, finally,
expanding again to cover all matches we provide.

This particular zip folder contains the CSV data for...
  All Big Bash League matches
...for which we have data, and is loosely based on the format that Retrosheet
uses for baseball, with some suitable hacks built in.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the newer "Ashwin" format?
Ideally I'd like to settle on a single CSV format so what should be kept
from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_original/
but the following is a brief summary of the details...

Each file has a 'version', multiple 'info' lines, and multiple 'ball' lines.
'version' is just 1.6.0, or 1.7.0 for now, and will change as I make changes.
The 'info' entries should be fairly self-explanatory but feel free to ask on
Mastodon (@cricsheet@deeden.co.uk) if you're unsure. If you look carefully
you may see some slight hints as to some data we'll be including in the full
data files in the future.

Each 'ball' line has the following fields:

  * The word 'ball' to identify it as such
  * Innings number, starting from 1
  * Over and ball
  * Batting team name
  * Batsman
  * Non-striker
  * Bowler
  * Runs-off-bat
  * Extras
  * Wides
  * No-balls
  * Byes
  * Leg-byes
  * Penalty
  * Kind of wicket, if any
  * Dismissed played, if there was a wicket

Matches included in this archive
--------------------------------

2016-12-20 - club - BBL - male - 1023581 - Sydney Thunder vs Sydney Sixers
2016-12-21 - club - BBL - male - 1023583 - Adelaide Strikers vs Brisbane Heat
2016-12-22 - club - BBL - male - 1023585 - Melbourne Renegades vs Sydney Thunder
2016-12-23 - club - BBL - male - 1023587 - Sydney Sixers vs Hobart Hurricanes
2016-12-23 - club - BBL - male - 1023589 - Perth Scorchers vs Adelaide Strikers
2016-12-26 - club - BBL - male - 1023591 - Hobart Hurricanes vs Melbourne Stars
2016-12-27 - club - BBL - male - 1023593 - Sydney Sixers vs Perth Scorchers
2016-12-28 - club - BBL - male - 1023595 - Sydney Thunder vs Brisbane Heat
2016-12-29 - club - BBL - male - 1023597 - Melbourne Renegades vs Perth Scorchers
2016-12-30 - club - BBL - male - 1023599 - Brisbane Heat vs Hobart Hurricanes
2016-12-31 - club - BBL - male - 1023601 - Adelaide Strikers vs Sydney Sixers
2017-01-01 - club - BBL - male - 1023603 - Melbourne Stars vs Melbourne Renegades
2017-01-01 - club - BBL - male - 1023605 - Perth Scorchers vs Sydney Thunder
2017-01-02 - club - BBL - male - 1023607 - Hobart Hurricanes vs Adelaide Strikers
2017-01-03 - club - BBL - male - 1023609 - Brisbane Heat vs Sydney Sixers
2017-01-04 - club - BBL - male - 1023611 - Sydney Thunder vs Melbourne Stars
2017-01-05 - club - BBL - male - 1023613 - Perth Scorchers vs Brisbane Heat
2017-01-06 - club - BBL - male - 1023615 - Adelaide Strikers vs Hobart Hurricanes
2017-01-07 - club - BBL - male - 1023617 - Melbourne Renegades vs Melbourne Stars
2017-01-08 - club - BBL - male - 1023619 - Hobart Hurricanes vs Sydney Thunder
2017-01-09 - club - BBL - male - 1023621 - Sydney Sixers vs Melbourne Renegades
2017-01-10 - club - BBL - male - 1023623 - Melbourne Stars vs Adelaide Strikers
2017-01-11 - club - BBL - male - 1023625 - Brisbane Heat vs Perth Scorchers
2017-01-12 - club - BBL - male - 1023627 - Melbourne Renegades vs Hobart Hurricanes
2017-01-14 - club - BBL - male - 1023629 - Sydney Sixers vs Sydney Thunder
2017-01-14 - club - BBL - male - 1023631 - Perth Scorchers vs Melbourne Stars
2017-01-16 - club - BBL - male - 1023633 - Adelaide Strikers vs Melbourne Renegades
2017-01-17 - club - BBL - male - 1023635 - Melbourne Stars vs Brisbane Heat
2017-01-18 - club - BBL - male - 1023637 - Sydney Thunder vs Adelaide Strikers
2017-01-20 - club - BBL - male - 1023639 - Brisbane Heat vs Melbourne Renegades
2017-01-21 - club - BBL - male - 1023641 - Hobart Hurricanes vs Perth Scorchers
2017-01-21 - club - BBL - male - 1023643 - Melbourne Stars vs Sydney Sixers
2017-01-24 - club - BBL - male - 1023645 - Perth Scorchers vs Melbourne Stars
2017-01-25 - club - BBL - male - 1023647 - Brisbane Heat vs Sydney Sixers
2017-01-28 - club - BBL - male - 1023649 - Perth Scorchers vs Sydney Sixers
2017-12-19 - club - BBL - male - 1114856 - Sydney Thunder vs Sydney Sixers
2017-12-20 - club - BBL - male - 1114857 - Brisbane Heat vs Melbourne Stars
2017-12-21 - club - BBL - male - 1114858 - Hobart Hurricanes vs Melbourne Renegades
2017-12-22 - club - BBL - male - 1114859 - Adelaide Strikers vs Sydney Thunder
2017-12-23 - club - BBL - male - 1114860 - Sydney Sixers vs Perth Scorchers
2017-12-23 - club - BBL - male - 1114861 - Melbourne Renegades vs Brisbane Heat
2017-12-26 - club - BBL - male - 1114862 - Perth Scorchers vs Melbourne Stars
2017-12-27 - club - BBL - male - 1114863 - Brisbane Heat vs Sydney Thunder
2017-12-28 - club - BBL - male - 1114864 - Sydney Sixers vs Adelaide Strikers
2017-12-29 - club - BBL - male - 1114865 - Melbourne Renegades vs Perth Scorchers
2017-12-30 - club - BBL - male - 1114866 - Hobart Hurricanes vs Sydney Thunder
2017-12-31 - club - BBL - male - 1114867 - Adelaide Strikers vs Brisbane Heat
2018-01-01 - club - BBL - male - 1114868 - Sydney Thunder vs Hobart Hurricanes
2018-01-01 - club - BBL - male - 1114869 - Perth Scorchers vs Sydney Sixers
2018-01-02 - club - BBL - male - 1114870 - Melbourne Stars vs Brisbane Heat
2018-01-03 - club - BBL - male - 1114871 - Melbourne Renegades vs Sydney Sixers
2018-01-04 - club - BBL - male - 1114872 - Hobart Hurricanes vs Adelaide Strikers
2018-01-05 - club - BBL - male - 1114873 - Brisbane Heat vs Perth Scorchers
2018-01-06 - club - BBL - male - 1114874 - Melbourne Stars vs Melbourne Renegades
2018-01-07 - club - BBL - male - 1114875 - Sydney Thunder vs Adelaide Strikers
2018-01-08 - club - BBL - male - 1114876 - Hobart Hurricanes vs Sydney Sixers
2018-01-08 - club - BBL - male - 1114877 - Perth Scorchers vs Melbourne Renegades
2018-01-09 - club - BBL - male - 1114878 - Adelaide Strikers vs Melbourne Stars
2018-01-10 - club - BBL - male - 1114879 - Brisbane Heat vs Hobart Hurricanes
2018-01-11 - club - BBL - male - 1114880 - Sydney Thunder vs Perth Scorchers
2018-01-12 - club - BBL - male - 1114881 - Melbourne Renegades vs Melbourne Stars
2018-01-13 - club - BBL - male - 1114882 - Adelaide Strikers vs Perth Scorchers
2018-01-13 - club - BBL - male - 1114883 - Sydney Sixers vs Sydney Thunder
2018-01-15 - club - BBL - male - 1114884 - Hobart Hurricanes vs Brisbane Heat
2018-01-16 - club - BBL - male - 1114885 - Melbourne Stars vs Sydney Sixers
2018-01-17 - club - BBL - male - 1114886 - Adelaide Strikers vs Hobart Hurricanes
2018-01-18 - club - BBL - male - 1114887 - Sydney Sixers vs Brisbane Heat
2018-01-20 - club - BBL - male - 1114888 - Melbourne Stars vs Sydney Thunder
2018-01-20 - club - BBL - male - 1114889 - Perth Scorchers vs Hobart Hurricanes
2018-01-22 - club - BBL - male - 1114890 - Melbourne Renegades vs Adelaide Strikers
2018-01-23 - club - BBL - male - 1114891 - Sydney Sixers vs Melbourne Stars
2018-01-24 - club - BBL - male - 1114892 - Sydney Thunder vs Melbourne Renegades
2018-01-25 - club - BBL - male - 1114893 - Perth Scorchers vs Adelaide Strikers
2018-01-27 - club - BBL - male - 1114894 - Melbourne Stars vs Hobart Hurricanes
2018-01-27 - club - BBL - male - 1114895 - Brisbane Heat vs Melbourne Renegades
2018-02-01 - club - BBL - male - 1114896 - Perth Scorchers vs Hobart Hurricanes
2018-02-02 - club - BBL - male - 1114897 - Adelaide Strikers vs Melbourne Renegades
2018-02-04 - club - BBL - male - 1114898 - Adelaide Strikers vs Hobart Hurricanes
2018-12-19 - club - BBL - male - 1152511 - Brisbane Heat vs Adelaide Strikers
2018-12-20 - club - BBL - male - 1152512 - Melbourne Renegades vs Perth Scorchers
2018-12-21 - club - BBL - male - 1152513 - Sydney Thunder vs Melbourne Stars
2018-12-22 - club - BBL - male - 1152514 - Sydney Sixers vs Perth Scorchers
2018-12-22 - club - BBL - male - 1152515 - Brisbane Heat vs Hobart Hurricanes
2018-12-23 - club - BBL - male - 1152516 - Adelaide Strikers vs Melbourne Renegades
2018-12-24 - club - BBL - male - 1152517 - Hobart Hurricanes vs Melbourne Stars
2018-12-24 - club - BBL - male - 1152518 - Sydney Thunder vs Sydney Sixers
2018-12-26 - club - BBL - male - 1152519 - Perth Scorchers vs Adelaide Strikers
2018-12-27 - club - BBL - male - 1152520 - Sydney Sixers vs Melbourne Stars
2018-12-28 - club - BBL - male - 1152521 - Hobart Hurricanes vs Sydney Thunder
2018-12-29 - club - BBL - male - 1152522 - Melbourne Renegades vs Sydney Sixers
2018-12-30 - club - BBL - male - 1152523 - Hobart Hurricanes vs Perth Scorchers
2018-12-31 - club - BBL - male - 1152524 - Adelaide Strikers vs Sydney Thunder
2019-01-01 - club - BBL - male - 1152525 - Brisbane Heat vs Sydney Sixers
2019-01-01 - club - BBL - male - 1152526 - Melbourne Stars vs Melbourne Renegades
2019-01-02 - club - BBL - male - 1152527 - Sydney Thunder vs Perth Scorchers
2019-01-03 - club - BBL - male - 1152528 - Melbourne Renegades vs Adelaide Strikers
2019-01-04 - club - BBL - male - 1152529 - Hobart Hurricanes vs Sydney Sixers
2019-01-05 - club - BBL - male - 1152530 - Melbourne Stars vs Sydney Thunder
2019-01-05 - club - BBL - male - 1152531 - Perth Scorchers vs Brisbane Heat
2019-01-06 - club - BBL - male - 1152532 - Adelaide Strikers vs Sydney Sixers
2019-01-07 - club - BBL - male - 1152533 - Melbourne Renegades vs Hobart Hurricanes
2019-01-08 - club - BBL - male - 1152534 - Sydney Thunder vs Brisbane Heat
2019-01-09 - club - BBL - male - 1152535 - Melbourne Stars vs Perth Scorchers
2019-01-10 - club - BBL - male - 1152536 - Brisbane Heat vs Melbourne Renegades
2019-01-11 - club - BBL - male - 1152537 - Adelaide Strikers vs Melbourne Stars
2019-01-13 - club - BBL - male - 1152538 - Sydney Thunder vs Adelaide Strikers
2019-01-13 - club - BBL - male - 1152539 - Melbourne Renegades vs Brisbane Heat
2019-01-13 - club - BBL - male - 1152540 - Perth Scorchers vs Sydney Sixers
2019-01-14 - club - BBL - male - 1152541 - Melbourne Stars vs Hobart Hurricanes
2019-01-16 - club - BBL - male - 1152542 - Sydney Sixers vs Melbourne Renegades
2019-01-17 - club - BBL - male - 1152543 - Brisbane Heat vs Sydney Thunder
2019-01-18 - club - BBL - male - 1152544 - Perth Scorchers vs Hobart Hurricanes
2019-01-19 - club - BBL - male - 1152545 - Melbourne Renegades vs Melbourne Stars
2019-01-20 - club - BBL - male - 1152546 - Sydney Sixers vs Brisbane Heat
2019-01-21 - club - BBL - male - 1152547 - Adelaide Strikers vs Hobart Hurricanes
2019-01-22 - club - BBL - male - 1152548 - Sydney Thunder vs Melbourne Renegades
2019-01-23 - club - BBL - male - 1152549 - Melbourne Stars vs Adelaide Strikers
2019-01-23 - club - BBL - male - 1152550 - Sydney Sixers vs Hobart Hurricanes
2019-01-24 - club - BBL - male - 1152551 - Perth Scorchers vs Sydney Thunder
2019-01-27 - club - BBL - male - 1152552 - Melbourne Stars vs Brisbane Heat
2019-01-28 - club - BBL - male - 1152553 - Perth Scorchers vs Melbourne Renegades
2019-01-29 - club - BBL - male - 1152554 - Hobart Hurricanes vs Brisbane Heat
2019-01-29 - club - BBL - male - 1152555 - Sydney Sixers vs Adelaide Strikers
2019-01-30 - club - BBL - male - 1152556 - Melbourne Renegades vs Sydney Thunder
2019-01-31 - club - BBL - male - 1152557 - Hobart Hurricanes vs Adelaide Strikers
2019-02-01 - club - BBL - male - 1152558 - Brisbane Heat vs Perth Scorchers
2019-02-02 - club - BBL - male - 1152559 - Sydney Sixers vs Sydney Thunder
2019-02-03 - club - BBL - male - 1152560 - Adelaide Strikers vs Brisbane Heat
2019-02-03 - club - BBL - male - 1152561 - Perth Scorchers vs Melbourne Stars
2019-02-07 - club - BBL - male - 1152562 - Hobart Hurricanes vs Melbourne Renegades
2019-02-08 - club - BBL - male - 1152563 - Brisbane Heat vs Melbourne Stars
2019-02-09 - club - BBL - male - 1152564 - Adelaide Strikers vs Perth Scorchers
2019-02-09 - club - BBL - male - 1152565 - Sydney Thunder vs Hobart Hurricanes
2019-02-10 - club - BBL - male - 1152566 - Melbourne Stars vs Sydney Sixers
2019-02-14 - club - BBL - male - 1152567 - Hobart Hurricanes vs Melbourne Stars
2019-02-15 - club - BBL - male - 1152568 - Melbourne Renegades vs Sydney Sixers
2019-02-17 - club - BBL - male - 1152569 - Melbourne Stars vs Melbourne Renegades
2019-12-17 - club - BBL - male - 1195573 - Brisbane Heat vs Sydney Thunder
2019-12-18 - club - BBL - male - 1195574 - Sydney Sixers vs Perth Scorchers
2019-12-19 - club - BBL - male - 1195575 - Melbourne Renegades vs Sydney Thunder
2019-12-20 - club - BBL - male - 1195576 - Hobart Hurricanes vs Sydney Sixers
2019-12-20 - club - BBL - male - 1195577 - Brisbane Heat vs Melbourne Stars
2019-12-21 - club - BBL - male - 1195578 - Sydney Thunder vs Adelaide Strikers
2019-12-21 - club - BBL - male - 1195579 - Perth Scorchers vs Melbourne Renegades
2019-12-22 - club - BBL - male - 1195580 - Melbourne Stars vs Hobart Hurricanes
2019-12-22 - club - BBL - male - 1195581 - Sydney Sixers vs Brisbane Heat
2019-12-23 - club - BBL - male - 1195582 - Adelaide Strikers vs Perth Scorchers
2019-12-24 - club - BBL - male - 1195583 - Hobart Hurricanes vs Melbourne Renegades
2019-12-26 - club - BBL - male - 1195584 - Perth Scorchers vs Sydney Sixers
2019-12-27 - club - BBL - male - 1195585 - Melbourne Stars vs Adelaide Strikers
2019-12-28 - club - BBL - male - 1195586 - Sydney Sixers vs Sydney Thunder
2019-12-29 - club - BBL - male - 1195587 - Melbourne Renegades vs Adelaide Strikers
2019-12-30 - club - BBL - male - 1195588 - Hobart Hurricanes vs Melbourne Stars
2019-12-31 - club - BBL - male - 1195589 - Adelaide Strikers vs Sydney Thunder
2020-01-01 - club - BBL - male - 1195590 - Brisbane Heat vs Perth Scorchers
2020-01-02 - club - BBL - male - 1195591 - Sydney Thunder vs Melbourne Stars
2020-01-02 - club - BBL - male - 1195592 - Melbourne Renegades vs Sydney Sixers
2020-01-03 - club - BBL - male - 1195593 - Hobart Hurricanes vs Brisbane Heat
2020-01-04 - club - BBL - male - 1195594 - Melbourne Stars vs Melbourne Renegades
2020-01-05 - club - BBL - male - 1195595 - Sydney Sixers vs Adelaide Strikers
2020-01-05 - club - BBL - male - 1195596 - Perth Scorchers vs Hobart Hurricanes
2020-01-06 - club - BBL - male - 1195597 - Sydney Thunder vs Brisbane Heat
2020-01-07 - club - BBL - male - 1195598 - Melbourne Renegades vs Perth Scorchers
2020-01-08 - club - BBL - male - 1195599 - Adelaide Strikers vs Sydney Sixers
2020-01-08 - club - BBL - male - 1195600 - Melbourne Stars vs Sydney Thunder
2020-01-09 - club - BBL - male - 1195601 - Brisbane Heat vs Hobart Hurricanes
2020-01-10 - club - BBL - male - 1195602 - Melbourne Renegades vs Melbourne Stars
2020-01-11 - club - BBL - male - 1195603 - Sydney Thunder vs Hobart Hurricanes
2020-01-11 - club - BBL - male - 1195604 - Perth Scorchers vs Brisbane Heat
2020-01-12 - club - BBL - male - 1195605 - Adelaide Strikers vs Melbourne Renegades
2020-01-12 - club - BBL - male - 1195606 - Melbourne Stars vs Sydney Sixers
2020-01-13 - club - BBL - male - 1195607 - Hobart Hurricanes vs Perth Scorchers
2020-01-14 - club - BBL - male - 1195608 - Brisbane Heat vs Adelaide Strikers
2020-01-15 - club - BBL - male - 1195609 - Sydney Thunder vs Melbourne Renegades
2020-01-15 - club - BBL - male - 1195610 - Perth Scorchers vs Melbourne Stars
2020-01-16 - club - BBL - male - 1195611 - Sydney Sixers vs Hobart Hurricanes
2020-01-17 - club - BBL - male - 1195612 - Adelaide Strikers vs Brisbane Heat
2020-01-18 - club - BBL - male - 1195613 - Melbourne Stars vs Perth Scorchers
2020-01-18 - club - BBL - male - 1195614 - Sydney Thunder vs Sydney Sixers
2020-01-19 - club - BBL - male - 1195615 - Hobart Hurricanes vs Adelaide Strikers
2020-01-19 - club - BBL - male - 1195616 - Brisbane Heat vs Melbourne Renegades
2020-01-20 - club - BBL - male - 1195617 - Sydney Sixers vs Melbourne Stars
2020-01-20 - club - BBL - male - 1195618 - Perth Scorchers vs Sydney Thunder
2020-01-21 - club - BBL - male - 1195619 - Melbourne Renegades vs Hobart Hurricanes
2020-01-22 - club - BBL - male - 1195620 - Adelaide Strikers vs Melbourne Stars
2020-01-23 - club - BBL - male - 1195621 - Brisbane Heat vs Sydney Sixers
2020-01-24 - club - BBL - male - 1195622 - Hobart Hurricanes vs Sydney Thunder
2020-01-24 - club - BBL - male - 1195623 - Perth Scorchers vs Adelaide Strikers
2020-01-25 - club - BBL - male - 1195624 - Sydney Sixers vs Melbourne Renegades
2020-01-25 - club - BBL - male - 1195625 - Melbourne Stars vs Brisbane Heat
2020-01-26 - club - BBL - male - 1195626 - Sydney Thunder vs Perth Scorchers
2020-01-26 - club - BBL - male - 1195627 - Adelaide Strikers vs Hobart Hurricanes
2020-01-27 - club - BBL - male - 1195628 - Melbourne Renegades vs Brisbane Heat
2020-01-30 - club - BBL - male - 1195629 - Hobart Hurricanes vs Sydney Thunder
2020-01-31 - club - BBL - male - 1195630 - Melbourne Stars vs Sydney Sixers
2020-02-01 - club - BBL - male - 1195631 - Adelaide Strikers vs Sydney Thunder
2020-02-06 - club - BBL - male - 1195632 - Melbourne Stars vs Sydney Thunder
2020-02-08 - club - BBL - male - 1195633 - Sydney Sixers vs Melbourne Stars
2021-01-08 - club - BBL - male - 1226826 - Adelaide Strikers vs Melbourne Renegades
2021-01-24 - club - BBL - male - 1226827 - Hobart Hurricanes vs Sydney Sixers
2020-12-12 - club - BBL - male - 1226828 - Melbourne Stars vs Sydney Thunder
2021-01-06 - club - BBL - male - 1226829 - Perth Scorchers vs Sydney Sixers
2020-12-19 - club - BBL - male - 1226830 - Melbourne Renegades vs Hobart Hurricanes
2020-12-22 - club - BBL - male - 1226831 - Perth Scorchers vs Sydney Thunder
2021-01-02 - club - BBL - male - 1226832 - Sydney Sixers vs Brisbane Heat
2021-01-05 - club - BBL - male - 1226833 - Adelaide Strikers vs Melbourne Renegades
2021-01-22 - club - BBL - male - 1226834 - Perth Scorchers vs Hobart Hurricanes
2021-01-07 - club - BBL - male - 1226835 - Brisbane Heat vs Melbourne Stars
2021-01-25 - club - BBL - male - 1226836 - Adelaide Strikers vs Sydney Thunder
2020-12-13 - club - BBL - male - 1226837 - Sydney Sixers vs Melbourne Renegades
2021-01-19 - club - BBL - male - 1226838 - Perth Scorchers vs Brisbane Heat
2021-01-15 - club - BBL - male - 1226839 - Melbourne Stars vs Adelaide Strikers
2021-01-18 - club - BBL - male - 1226840 - Sydney Thunder vs Hobart Hurricanes
2020-12-12 - club - BBL - male - 1226841 - Perth Scorchers vs Melbourne Renegades
2021-01-03 - club - BBL - male - 1226842 - Adelaide Strikers vs Sydney Sixers
2021-01-14 - club - BBL - male - 1226843 - Melbourne Renegades vs Brisbane Heat
2021-01-02 - club - BBL - male - 1226844 - Hobart Hurricanes vs Melbourne Stars
2020-12-28 - club - BBL - male - 1226845 - Adelaide Strikers vs Perth Scorchers
2020-12-26 - club - BBL - male - 1226846 - Melbourne Stars vs Sydney Sixers
2021-01-24 - club - BBL - male - 1226847 - Adelaide Strikers vs Sydney Thunder
2021-01-23 - club - BBL - male - 1226848 - Brisbane Heat vs Melbourne Renegades
2021-01-23 - club - BBL - male - 1226849 - Perth Scorchers vs Melbourne Stars
2020-12-13 - club - BBL - male - 1226850 - Hobart Hurricanes vs Adelaide Strikers
2021-01-04 - club - BBL - male - 1226851 - Sydney Thunder vs Brisbane Heat
2020-12-10 - club - BBL - male - 1226852 - Hobart Hurricanes vs Sydney Sixers
2021-01-03 - club - BBL - male - 1226853 - Perth Scorchers vs Melbourne Renegades
2020-12-29 - club - BBL - male - 1226854 - Sydney Thunder vs Melbourne Stars
2021-01-10 - club - BBL - male - 1226855 - Brisbane Heat vs Sydney Sixers
2021-01-01 - club - BBL - male - 1226856 - Melbourne Renegades vs Sydney Thunder
2021-01-12 - club - BBL - male - 1226857 - Hobart Hurricanes vs Perth Scorchers
2021-01-26 - club - BBL - male - 1226858 - Melbourne Stars vs Sydney Sixers
2021-01-21 - club - BBL - male - 1226859 - Adelaide Strikers vs Brisbane Heat
2021-01-26 - club - BBL - male - 1226860 - Melbourne Renegades vs Hobart Hurricanes
2021-01-13 - club - BBL - male - 1226861 - Sydney Thunder vs Sydney Sixers
2021-01-26 - club - BBL - male - 1226862 - Brisbane Heat vs Perth Scorchers
2020-12-15 - club - BBL - male - 1226863 - Hobart Hurricanes vs Adelaide Strikers
2021-01-17 - club - BBL - male - 1226864 - Melbourne Renegades vs Melbourne Stars
2021-01-16 - club - BBL - male - 1226865 - Perth Scorchers vs Sydney Sixers
2020-12-14 - club - BBL - male - 1226866 - Brisbane Heat vs Sydney Thunder
2020-12-16 - club - BBL - male - 1226867 - Perth Scorchers vs Melbourne Stars
2020-12-27 - club - BBL - male - 1226868 - Hobart Hurricanes vs Brisbane Heat
2021-01-20 - club - BBL - male - 1226869 - Melbourne Stars vs Melbourne Renegades
2020-12-31 - club - BBL - male - 1226870 - Adelaide Strikers vs Perth Scorchers
2021-01-07 - club - BBL - male - 1226871 - Sydney Thunder vs Hobart Hurricanes
2020-12-11 - club - BBL - male - 1226872 - Brisbane Heat vs Melbourne Stars
2020-12-20 - club - BBL - male - 1226873 - Sydney Sixers vs Adelaide Strikers
2020-12-26 - club - BBL - male - 1226874 - Sydney Thunder vs Melbourne Renegades
2020-12-30 - club - BBL - male - 1226875 - Hobart Hurricanes vs Brisbane Heat
2021-01-11 - club - BBL - male - 1226876 - Melbourne Stars vs Adelaide Strikers
2020-12-29 - club - BBL - male - 1226877 - Melbourne Renegades vs Sydney Sixers
2021-01-09 - club - BBL - male - 1226878 - Perth Scorchers vs Sydney Thunder
2021-01-04 - club - BBL - male - 1226879 - Melbourne Stars vs Hobart Hurricanes
2021-01-22 - club - BBL - male - 1226880 - Sydney Thunder vs Sydney Sixers
2020-12-23 - club - BBL - male - 1226881 - Adelaide Strikers vs Brisbane Heat
2021-02-06 - club - BBL - male - 1226882 - Sydney Sixers vs Perth Scorchers
2021-01-29 - club - BBL - male - 1226883 - Adelaide Strikers vs Brisbane Heat
2021-01-30 - club - BBL - male - 1226884 - Perth Scorchers vs Sydney Sixers
2021-01-31 - club - BBL - male - 1226885 - Sydney Thunder vs Brisbane Heat
2021-02-04 - club - BBL - male - 1226886 - Perth Scorchers vs Brisbane Heat
2021-12-05 - club - BBL - male - 1269638 - Sydney Sixers vs Melbourne Stars
2021-12-06 - club - BBL - male - 1269639 - Brisbane Heat vs Sydney Thunder
2021-12-07 - club - BBL - male - 1269640 - Melbourne Renegades vs Adelaide Strikers
2021-12-08 - club - BBL - male - 1269641 - Sydney Sixers vs Hobart Hurricanes
2021-12-08 - club - BBL - male - 1269642 - Perth Scorchers vs Brisbane Heat
2021-12-09 - club - BBL - male - 1269643 - Adelaide Strikers vs Melbourne Renegades
2021-12-10 - club - BBL - male - 1269644 - Melbourne Stars vs Sydney Thunder
2021-12-11 - club - BBL - male - 1269645 - Hobart Hurricanes vs Sydney Sixers
2021-12-11 - club - BBL - male - 1269646 - Perth Scorchers vs Adelaide Strikers
2021-12-12 - club - BBL - male - 1269647 - Sydney Thunder vs Melbourne Stars
2021-12-13 - club - BBL - male - 1269648 - Melbourne Renegades vs Brisbane Heat
2021-12-14 - club - BBL - male - 1269649 - Perth Scorchers vs Hobart Hurricanes
2021-12-15 - club - BBL - male - 1269650 - Melbourne Stars vs Sydney Sixers
2021-12-19 - club - BBL - male - 1269651 - Sydney Thunder vs Brisbane Heat
2021-12-20 - club - BBL - male - 1269652 - Perth Scorchers vs Hobart Hurricanes
2021-12-21 - club - BBL - male - 1269653 - Adelaide Strikers vs Sydney Sixers
2021-12-22 - club - BBL - male - 1269654 - Perth Scorchers vs Melbourne Renegades
2021-12-23 - club - BBL - male - 1269655 - Brisbane Heat vs Adelaide Strikers
2021-12-24 - club - BBL - male - 1269656 - Hobart Hurricanes vs Melbourne Stars
2021-12-26 - club - BBL - male - 1269657 - Sydney Sixers vs Sydney Thunder
2021-12-26 - club - BBL - male - 1269658 - Melbourne Renegades vs Perth Scorchers
2021-12-27 - club - BBL - male - 1269659 - Adelaide Strikers vs Hobart Hurricanes
2021-12-27 - club - BBL - male - 1269660 - Melbourne Stars vs Brisbane Heat
2021-12-28 - club - BBL - male - 1269661 - Sydney Thunder vs Perth Scorchers
2021-12-29 - club - BBL - male - 1269662 - Brisbane Heat vs Sydney Sixers
2021-12-29 - club - BBL - male - 1269663 - Hobart Hurricanes vs Melbourne Renegades
2022-01-11 - club - BBL - male - 1269664 - Perth Scorchers vs Melbourne Stars
2021-12-31 - club - BBL - male - 1269665 - Sydney Thunder vs Adelaide Strikers
2022-01-01 - club - BBL - male - 1269666 - Brisbane Heat vs Hobart Hurricanes
2022-01-02 - club - BBL - male - 1269668 - Perth Scorchers vs Melbourne Stars
2022-01-02 - club - BBL - male - 1269669 - Sydney Thunder vs Adelaide Strikers
2022-01-03 - club - BBL - male - 1269670 - Melbourne Stars vs Melbourne Renegades
2022-01-21 - club - BBL - male - 1269671 - Adelaide Strikers vs Hobart Hurricanes
2022-01-05 - club - BBL - male - 1269672 - Hobart Hurricanes vs Adelaide Strikers
2022-01-06 - club - BBL - male - 1269673 - Perth Scorchers vs Sydney Thunder
2022-01-06 - club - BBL - male - 1269674 - Brisbane Heat vs Melbourne Renegades
2022-01-04 - club - BBL - male - 1269675 - Perth Scorchers vs Sydney Sixers
2022-01-15 - club - BBL - male - 1269676 - Adelaide Strikers vs Melbourne Stars
2022-01-08 - club - BBL - male - 1269677 - Sydney Thunder vs Melbourne Renegades
2022-01-08 - club - BBL - male - 1269678 - Brisbane Heat vs Hobart Hurricanes
2022-01-09 - club - BBL - male - 1269679 - Sydney Sixers vs Perth Scorchers
2022-01-10 - club - BBL - male - 1269680 - Adelaide Strikers vs Melbourne Stars
2022-01-10 - club - BBL - male - 1269681 - Hobart Hurricanes vs Sydney Thunder
2022-01-11 - club - BBL - male - 1269682 - Sydney Sixers vs Melbourne Renegades
2022-01-12 - club - BBL - male - 1269683 - Adelaide Strikers vs Brisbane Heat
2022-01-13 - club - BBL - male - 1269684 - Hobart Hurricanes vs Sydney Thunder
2022-01-13 - club - BBL - male - 1269685 - Melbourne Renegades vs Melbourne Stars
2022-01-14 - club - BBL - male - 1269686 - Perth Scorchers vs Adelaide Strikers
2022-01-15 - club - BBL - male - 1269687 - Sydney Sixers vs Sydney Thunder
2022-01-16 - club - BBL - male - 1269688 - Brisbane Heat vs Melbourne Stars
2022-01-17 - club - BBL - male - 1269689 - Sydney Sixers vs Adelaide Strikers
2022-01-17 - club - BBL - male - 1269690 - Brisbane Heat vs Perth Scorchers
2022-01-18 - club - BBL - male - 1269691 - Hobart Hurricanes vs Melbourne Renegades
2022-01-19 - club - BBL - male - 1269692 - Sydney Sixers vs Brisbane Heat
2022-01-19 - club - BBL - male - 1269693 - Melbourne Stars vs Hobart Hurricanes
2022-01-19 - club - BBL - male - 1269694 - Sydney Thunder vs Melbourne Renegades
2022-01-22 - club - BBL - male - 1269695 - Perth Scorchers vs Sydney Sixers
2022-01-23 - club - BBL - male - 1269696 - Adelaide Strikers vs Sydney Thunder
2022-01-26 - club - BBL - male - 1269697 - Adelaide Strikers vs Sydney Sixers
2022-01-28 - club - BBL - male - 1269698 - Perth Scorchers vs Sydney Sixers
2022-12-13 - club - BBL - male - 1324624 - Melbourne Stars vs Sydney Thunder
2022-12-14 - club - BBL - male - 1324625 - Adelaide Strikers vs Sydney Sixers
2022-12-15 - club - BBL - male - 1324626 - Melbourne Renegades vs Brisbane Heat
2022-12-16 - club - BBL - male - 1324627 - Melbourne Stars vs Hobart Hurricanes
2022-12-16 - club - BBL - male - 1324628 - Adelaide Strikers vs Sydney Thunder
2022-12-17 - club - BBL - male - 1324629 - Perth Scorchers vs Sydney Sixers
2022-12-18 - club - BBL - male - 1324630 - Sydney Thunder vs Melbourne Renegades
2022-12-19 - club - BBL - male - 1324631 - Hobart Hurricanes vs Perth Scorchers
2022-12-20 - club - BBL - male - 1324632 - Sydney Thunder vs Adelaide Strikers
2022-12-21 - club - BBL - male - 1324633 - Brisbane Heat vs Melbourne Renegades
2022-12-22 - club - BBL - male - 1324634 - Sydney Sixers vs Hobart Hurricanes
2022-12-23 - club - BBL - male - 1324635 - Perth Scorchers vs Melbourne Stars
2022-12-23 - club - BBL - male - 1324636 - Brisbane Heat vs Adelaide Strikers
2022-12-24 - club - BBL - male - 1324637 - Hobart Hurricanes vs Melbourne Renegades
2022-12-26 - club - BBL - male - 1324638 - Melbourne Stars vs Sydney Sixers
2022-12-26 - club - BBL - male - 1324639 - Adelaide Strikers vs Perth Scorchers
2022-12-27 - club - BBL - male - 1324640 - Brisbane Heat vs Sydney Thunder
2022-12-28 - club - BBL - male - 1324641 - Sydney Sixers vs Melbourne Renegades
2022-12-29 - club - BBL - male - 1324642 - Sydney Thunder vs Brisbane Heat
2022-12-29 - club - BBL - male - 1324643 - Melbourne Stars vs Perth Scorchers
2022-12-30 - club - BBL - male - 1324644 - Melbourne Renegades vs Sydney Sixers
2022-12-31 - club - BBL - male - 1324645 - Sydney Thunder vs Hobart Hurricanes
2022-12-31 - club - BBL - male - 1324646 - Melbourne Stars vs Adelaide Strikers
2023-01-01 - club - BBL - male - 1324647 - Melbourne Renegades vs Perth Scorchers
2023-01-01 - club - BBL - male - 1324648 - Brisbane Heat vs Sydney Sixers
2023-01-02 - club - BBL - male - 1324649 - Adelaide Strikers vs Hobart Hurricanes
2023-01-03 - club - BBL - male - 1324650 - Melbourne Renegades vs Melbourne Stars
2023-01-04 - club - BBL - male - 1324651 - Brisbane Heat vs Sydney Sixers
2023-01-04 - club - BBL - male - 1324652 - Perth Scorchers vs Sydney Thunder
2023-01-05 - club - BBL - male - 1324653 - Hobart Hurricanes vs Adelaide Strikers
2023-01-06 - club - BBL - male - 1324654 - Melbourne Stars vs Sydney Sixers
2023-01-07 - club - BBL - male - 1324655 - Hobart Hurricanes vs Melbourne Renegades
2023-01-07 - club - BBL - male - 1324656 - Brisbane Heat vs Perth Scorchers
2023-01-08 - club - BBL - male - 1324657 - Sydney Thunder vs Sydney Sixers
2023-01-09 - club - BBL - male - 1324658 - Melbourne Stars vs Hobart Hurricanes
2023-01-10 - club - BBL - male - 1324659 - Adelaide Strikers vs Melbourne Renegades
2023-01-11 - club - BBL - male - 1324660 - Brisbane Heat vs Perth Scorchers
2023-01-12 - club - BBL - male - 1324661 - Adelaide Strikers vs Melbourne Stars
2023-01-13 - club - BBL - male - 1324662 - Sydney Thunder vs Perth Scorchers
2023-01-14 - club - BBL - male - 1324663 - Brisbane Heat vs Adelaide Strikers
2023-01-14 - club - BBL - male - 1324664 - Melbourne Renegades vs Melbourne Stars
2023-01-15 - club - BBL - male - 1324665 - Sydney Thunder vs Hobart Hurricanes
2023-01-15 - club - BBL - male - 1324666 - Sydney Sixers vs Perth Scorchers
2023-01-16 - club - BBL - male - 1324667 - Melbourne Stars vs Brisbane Heat
2023-01-17 - club - BBL - male - 1324668 - Sydney Sixers vs Adelaide Strikers
2023-01-18 - club - BBL - male - 1324669 - Hobart Hurricanes vs Perth Scorchers
2023-01-19 - club - BBL - male - 1324670 - Melbourne Renegades vs Sydney Thunder
2023-01-20 - club - BBL - male - 1324671 - Adelaide Strikers vs Perth Scorchers
2023-01-20 - club - BBL - male - 1324672 - Brisbane Heat vs Hobart Hurricanes
2023-01-21 - club - BBL - male - 1324673 - Sydney Sixers vs Sydney Thunder
2023-01-22 - club - BBL - male - 1324674 - Brisbane Heat vs Melbourne Stars
2023-01-22 - club - BBL - male - 1324675 - Perth Scorchers vs Melbourne Renegades
2023-01-23 - club - BBL - male - 1324676 - Sydney Sixers vs Hobart Hurricanes
2023-01-24 - club - BBL - male - 1324677 - Adelaide Strikers vs Melbourne Renegades
2023-01-25 - club - BBL - male - 1324678 - Hobart Hurricanes vs Brisbane Heat
2023-01-25 - club - BBL - male - 1324679 - Melbourne Stars vs Sydney Thunder
2023-01-27 - club - BBL - male - 1324680 - Brisbane Heat vs Sydney Thunder
2023-01-28 - club - BBL - male - 1324681 - Sydney Sixers vs Perth Scorchers
2023-01-29 - club - BBL - male - 1324682 - Melbourne Renegades vs Brisbane Heat
2023-02-02 - club - BBL - male - 1324683 - Sydney Sixers vs Brisbane Heat
2023-02-04 - club - BBL - male - 1324684 - Brisbane Heat vs Perth Scorchers
2023-12-07 - club - BBL - male - 1386094 - Brisbane Heat vs Melbourne Stars
2023-12-08 - club - BBL - male - 1386095 - Sydney Sixers vs Melbourne Renegades
2023-12-10 - club - BBL - male - 1386097 - Perth Scorchers vs Melbourne Renegades
2023-12-11 - club - BBL - male - 1386098 - Hobart Hurricanes vs Sydney Sixers
2023-12-12 - club - BBL - male - 1386099 - Brisbane Heat vs Sydney Thunder
2023-12-13 - club - BBL - male - 1386100 - Melbourne Stars vs Perth Scorchers
2023-12-19 - club - BBL - male - 1386101 - Sydney Thunder vs Adelaide Strikers
2023-12-20 - club - BBL - male - 1386102 - Hobart Hurricanes vs Perth Scorchers
2023-12-21 - club - BBL - male - 1386103 - Melbourne Renegades vs Brisbane Heat
2023-12-22 - club - BBL - male - 1386104 - Sydney Sixers vs Adelaide Strikers
2023-12-23 - club - BBL - male - 1386105 - Melbourne Stars vs Sydney Thunder
2023-12-23 - club - BBL - male - 1386106 - Melbourne Renegades vs Hobart Hurricanes
2023-12-26 - club - BBL - male - 1386107 - Sydney Sixers vs Melbourne Stars
2023-12-26 - club - BBL - male - 1386108 - Perth Scorchers vs Melbourne Renegades
2023-12-27 - club - BBL - male - 1386109 - Brisbane Heat vs Sydney Thunder
2023-12-28 - club - BBL - male - 1386110 - Hobart Hurricanes vs Melbourne Stars
2023-12-29 - club - BBL - male - 1386111 - Adelaide Strikers vs Melbourne Renegades
2023-12-30 - club - BBL - male - 1386112 - Sydney Thunder vs Sydney Sixers
2023-12-31 - club - BBL - male - 1386113 - Adelaide Strikers vs Melbourne Stars
2024-01-01 - club - BBL - male - 1386114 - Sydney Thunder vs Hobart Hurricanes
2024-01-02 - club - BBL - male - 1386116 - Melbourne Renegades vs Melbourne Stars
2024-01-03 - club - BBL - male - 1386117 - Sydney Sixers vs Brisbane Heat
2024-01-03 - club - BBL - male - 1386118 - Perth Scorchers vs Adelaide Strikers
2024-01-04 - club - BBL - male - 1386119 - Melbourne Renegades vs Hobart Hurricanes
2024-01-05 - club - BBL - male - 1386120 - Perth Scorchers vs Adelaide Strikers
2024-01-06 - club - BBL - male - 1386121 - Melbourne Stars vs Sydney Sixers
2024-01-07 - club - BBL - male - 1386122 - Brisbane Heat vs Hobart Hurricanes
2024-01-08 - club - BBL - male - 1386123 - Sydney Thunder vs Perth Scorchers
2024-01-09 - club - BBL - male - 1386124 - Hobart Hurricanes vs Adelaide Strikers
2024-01-10 - club - BBL - male - 1386125 - Brisbane Heat vs Perth Scorchers
2024-01-11 - club - BBL - male - 1386126 - Hobart Hurricanes vs Adelaide Strikers
2024-01-12 - club - BBL - male - 1386127 - Sydney Sixers vs Sydney Thunder
2024-01-13 - club - BBL - male - 1386128 - Perth Scorchers vs Brisbane Heat
2024-01-13 - club - BBL - male - 1386129 - Melbourne Stars vs Melbourne Renegades
2024-01-14 - club - BBL - male - 1386130 - Sydney Thunder vs Adelaide Strikers
2024-01-15 - club - BBL - male - 1386131 - Hobart Hurricanes vs Melbourne Stars
2024-01-16 - club - BBL - male - 1386132 - Perth Scorchers vs Sydney Sixers
2024-01-19 - club - BBL - male - 1386134 - Sydney Sixers vs Brisbane Heat
2024-01-20 - club - BBL - male - 1386135 - Adelaide Strikers vs Perth Scorchers
2024-01-22 - club - BBL - male - 1386136 - Brisbane Heat vs Adelaide Strikers
2024-01-24 - club - BBL - male - 1386137 - Brisbane Heat vs Sydney Sixers
2011-12-16 - club - BBL - male - 524915 - Sydney Sixers vs Brisbane Heat
2011-12-17 - club - BBL - male - 524916 - Melbourne Stars vs Sydney Thunder
2011-12-18 - club - BBL - male - 524917 - Adelaide Strikers vs Melbourne Renegades
2011-12-18 - club - BBL - male - 524918 - Perth Scorchers vs Hobart Hurricanes
2011-12-20 - club - BBL - male - 524919 - Brisbane Heat vs Melbourne Stars
2011-12-21 - club - BBL - male - 524920 - Hobart Hurricanes vs Sydney Sixers
2011-12-22 - club - BBL - male - 524921 - Melbourne Renegades vs Perth Scorchers
2011-12-23 - club - BBL - male - 524922 - Sydney Thunder vs Adelaide Strikers
2011-12-27 - club - BBL - male - 524923 - Sydney Sixers vs Melbourne Stars
2011-12-28 - club - BBL - male - 524924 - Adelaide Strikers vs Hobart Hurricanes
2011-12-29 - club - BBL - male - 524925 - Perth Scorchers vs Brisbane Heat
2011-12-30 - club - BBL - male - 524926 - Sydney Thunder vs Melbourne Renegades
2012-01-01 - club - BBL - male - 524927 - Hobart Hurricanes vs Sydney Thunder
2012-01-02 - club - BBL - male - 524928 - Melbourne Renegades vs Sydney Sixers
2012-01-04 - club - BBL - male - 524930 - Melbourne Stars vs Perth Scorchers
2012-01-08 - club - BBL - male - 524933 - Sydney Thunder vs Sydney Sixers
2012-01-08 - club - BBL - male - 524934 - Perth Scorchers vs Adelaide Strikers
2012-01-09 - club - BBL - male - 524935 - Hobart Hurricanes vs Melbourne Stars
2012-01-10 - club - BBL - male - 524936 - Adelaide Strikers vs Sydney Sixers
2012-01-12 - club - BBL - male - 524938 - Melbourne Renegades vs Brisbane Heat
2012-01-17 - club - BBL - male - 524939 - Brisbane Heat vs Sydney Thunder
2012-01-18 - club - BBL - male - 524940 - Hobart Hurricanes vs Melbourne Renegades
2012-01-18 - club - BBL - male - 524941 - Sydney Sixers vs Perth Scorchers
2012-01-19 - club - BBL - male - 524942 - Melbourne Stars vs Adelaide Strikers
2012-01-21 - club - BBL - male - 524943 - Perth Scorchers vs Melbourne Stars
2012-01-22 - club - BBL - male - 524944 - Hobart Hurricanes vs Sydney Sixers
2012-01-28 - club - BBL - male - 524945 - Perth Scorchers vs Sydney Sixers
2012-12-07 - club - BBL - male - 571232 - Melbourne Renegades vs Melbourne Stars
2012-12-08 - club - BBL - male - 571233 - Sydney Sixers vs Sydney Thunder
2012-12-09 - club - BBL - male - 571234 - Brisbane Heat vs Hobart Hurricanes
2012-12-09 - club - BBL - male - 571235 - Perth Scorchers vs Adelaide Strikers
2012-12-12 - club - BBL - male - 571236 - Perth Scorchers vs Melbourne Stars
2012-12-13 - club - BBL - male - 571237 - Adelaide Strikers vs Brisbane Heat
2012-12-14 - club - BBL - male - 571238 - Sydney Thunder vs Melbourne Renegades
2012-12-15 - club - BBL - male - 571239 - Melbourne Stars vs Hobart Hurricanes
2012-12-16 - club - BBL - male - 571240 - Sydney Sixers vs Perth Scorchers
2012-12-18 - club - BBL - male - 571241 - Brisbane Heat vs Perth Scorchers
2012-12-19 - club - BBL - male - 571242 - Melbourne Renegades vs Hobart Hurricanes
2012-12-20 - club - BBL - male - 571243 - Sydney Thunder vs Adelaide Strikers
2012-12-22 - club - BBL - male - 571245 - Melbourne Renegades vs Brisbane Heat
2012-12-23 - club - BBL - male - 571247 - Adelaide Strikers vs Sydney Sixers
2012-12-26 - club - BBL - male - 571248 - Sydney Sixers vs Hobart Hurricanes
2012-12-27 - club - BBL - male - 571249 - Adelaide Strikers vs Melbourne Stars
2012-12-28 - club - BBL - male - 571250 - Sydney Thunder vs Brisbane Heat
2012-12-29 - club - BBL - male - 571251 - Perth Scorchers vs Melbourne Renegades
2012-12-30 - club - BBL - male - 571252 - Sydney Thunder vs Sydney Sixers
2013-01-02 - club - BBL - male - 571254 - Melbourne Renegades vs Adelaide Strikers
2013-01-04 - club - BBL - male - 571256 - Perth Scorchers vs Sydney Thunder
2013-01-06 - club - BBL - male - 571258 - Melbourne Stars vs Melbourne Renegades
2013-01-07 - club - BBL - male - 571259 - Brisbane Heat vs Sydney Sixers
2013-01-08 - club - BBL - male - 571260 - Melbourne Stars vs Sydney Thunder
2013-01-10 - club - BBL - male - 571262 - Adelaide Strikers vs Perth Scorchers
2013-01-15 - club - BBL - male - 571264 - Melbourne Renegades vs Brisbane Heat
2013-01-16 - club - BBL - male - 571265 - Perth Scorchers vs Melbourne Stars
2013-01-19 - club - BBL - male - 571266 - Perth Scorchers vs Brisbane Heat
2013-12-20 - club - BBL - male - 654031 - Melbourne Stars vs Melbourne Renegades
2013-12-21 - club - BBL - male - 654033 - Sydney Sixers vs Sydney Thunder
2013-12-22 - club - BBL - male - 654035 - Hobart Hurricanes vs Adelaide Strikers
2013-12-22 - club - BBL - male - 654037 - Brisbane Heat vs Perth Scorchers
2013-12-26 - club - BBL - male - 654039 - Perth Scorchers vs Melbourne Renegades
2013-12-27 - club - BBL - male - 654041 - Sydney Thunder vs Adelaide Strikers
2013-12-28 - club - BBL - male - 654043 - Brisbane Heat vs Hobart Hurricanes
2013-12-29 - club - BBL - male - 654045 - Sydney Sixers vs Melbourne Stars
2013-12-30 - club - BBL - male - 654047 - Melbourne Renegades vs Brisbane Heat
2014-01-01 - club - BBL - male - 654051 - Hobart Hurricanes vs Melbourne Renegades
2014-01-01 - club - BBL - male - 654053 - Sydney Thunder vs Melbourne Stars
2014-01-02 - club - BBL - male - 654055 - Brisbane Heat vs Sydney Sixers
2014-01-03 - club - BBL - male - 654057 - Perth Scorchers vs Sydney Thunder
2014-01-04 - club - BBL - male - 654059 - Melbourne Renegades vs Melbourne Stars
2014-01-05 - club - BBL - male - 654061 - Adelaide Strikers vs Sydney Sixers
2014-01-07 - club - BBL - male - 654063 - Perth Scorchers vs Hobart Hurricanes
2014-01-08 - club - BBL - male - 654065 - Sydney Thunder vs Brisbane Heat
2014-01-09 - club - BBL - male - 654067 - Melbourne Stars vs Adelaide Strikers
2014-01-10 - club - BBL - male - 654069 - Sydney Sixers vs Perth Scorchers
2014-01-11 - club - BBL - male - 654071 - Hobart Hurricanes vs Sydney Thunder
2014-01-11 - club - BBL - male - 654073 - Brisbane Heat vs Melbourne Stars
2014-01-14 - club - BBL - male - 654075 - Melbourne Renegades vs Sydney Thunder
2014-01-15 - club - BBL - male - 654077 - Sydney Sixers vs Hobart Hurricanes
2014-01-16 - club - BBL - male - 654079 - Perth Scorchers vs Adelaide Strikers
2014-01-18 - club - BBL - male - 654081 - Adelaide Strikers vs Brisbane Heat
2014-01-18 - club - BBL - male - 654083 - Melbourne Renegades vs Sydney Sixers
2014-01-21 - club - BBL - male - 654085 - Melbourne Stars vs Hobart Hurricanes
2014-01-22 - club - BBL - male - 654087 - Adelaide Strikers vs Melbourne Renegades
2014-01-23 - club - BBL - male - 654089 - Hobart Hurricanes vs Brisbane Heat
2014-01-25 - club - BBL - male - 654091 - Sydney Thunder vs Sydney Sixers
2014-01-27 - club - BBL - male - 654093 - Melbourne Stars vs Perth Scorchers
2014-02-04 - club - BBL - male - 654095 - Melbourne Stars vs Hobart Hurricanes
2014-02-05 - club - BBL - male - 654097 - Sydney Sixers vs Perth Scorchers
2014-02-07 - club - BBL - male - 654099 - Perth Scorchers vs Hobart Hurricanes
2014-12-18 - club - BBL - male - 756735 - Adelaide Strikers vs Melbourne Stars
2014-12-19 - club - BBL - male - 756737 - Sydney Sixers vs Melbourne Renegades
2014-12-20 - club - BBL - male - 756739 - Melbourne Stars vs Hobart Hurricanes
2014-12-21 - club - BBL - male - 756741 - Sydney Thunder vs Brisbane Heat
2014-12-22 - club - BBL - male - 756743 - Perth Scorchers vs Adelaide Strikers
2014-12-23 - club - BBL - male - 756745 - Hobart Hurricanes vs Sydney Sixers
2014-12-26 - club - BBL - male - 756747 - Perth Scorchers vs Melbourne Renegades
2014-12-27 - club - BBL - male - 756749 - Sydney Thunder vs Sydney Sixers
2014-12-28 - club - BBL - male - 756751 - Brisbane Heat vs Melbourne Stars
2014-12-29 - club - BBL - male - 756753 - Sydney Sixers vs Perth Scorchers
2014-12-30 - club - BBL - male - 756755 - Melbourne Renegades vs Sydney Thunder
2014-12-31 - club - BBL - male - 756757 - Adelaide Strikers vs Hobart Hurricanes
2015-01-01 - club - BBL - male - 756759 - Perth Scorchers vs Sydney Thunder
2015-01-02 - club - BBL - male - 756761 - Hobart Hurricanes vs Brisbane Heat
2015-01-03 - club - BBL - male - 756763 - Melbourne Renegades vs Melbourne Stars
2015-01-04 - club - BBL - male - 756765 - Brisbane Heat vs Adelaide Strikers
2015-01-05 - club - BBL - male - 756767 - Melbourne Stars vs Sydney Sixers
2015-01-06 - club - BBL - male - 756769 - Adelaide Strikers vs Perth Scorchers
2015-01-08 - club - BBL - male - 756773 - Perth Scorchers vs Brisbane Heat
2015-01-22 - club - BBL - male - 756775 - Sydney Sixers vs Sydney Thunder
2015-01-10 - club - BBL - male - 756777 - Melbourne Stars vs Melbourne Renegades
2015-01-11 - club - BBL - male - 756779 - Hobart Hurricanes vs Perth Scorchers
2015-01-11 - club - BBL - male - 756781 - Brisbane Heat vs Sydney Sixers
2015-01-12 - club - BBL - male - 756783 - Adelaide Strikers vs Sydney Thunder
2015-01-13 - club - BBL - male - 756785 - Melbourne Renegades vs Brisbane Heat
2015-01-14 - club - BBL - male - 756787 - Sydney Sixers vs Adelaide Strikers
2015-01-07 - club - BBL - male - 756789 - Hobart Hurricanes vs Melbourne Renegades
2015-01-17 - club - BBL - male - 756791 - Sydney Thunder vs Melbourne Stars
2015-01-19 - club - BBL - male - 756793 - Melbourne Renegades vs Adelaide Strikers
2015-01-21 - club - BBL - male - 756795 - Melbourne Stars vs Perth Scorchers
2015-01-15 - club - BBL - male - 756797 - Brisbane Heat vs Hobart Hurricanes
2015-01-24 - club - BBL - male - 756799 - Adelaide Strikers vs Sydney Sixers
2015-01-25 - club - BBL - male - 756801 - Perth Scorchers vs Melbourne Stars
2015-01-28 - club - BBL - male - 756803 - Perth Scorchers vs Sydney Sixers
2015-12-18 - club - BBL - male - 897697 - Adelaide Strikers vs Melbourne Stars
2015-12-19 - club - BBL - male - 897699 - Brisbane Heat vs Melbourne Renegades
2015-12-20 - club - BBL - male - 897701 - Sydney Sixers vs Hobart Hurricanes
2015-12-21 - club - BBL - male - 897705 - Perth Scorchers vs Adelaide Strikers
2015-12-22 - club - BBL - male - 897707 - Hobart Hurricanes vs Brisbane Heat
2015-12-23 - club - BBL - male - 897709 - Melbourne Renegades vs Sydney Sixers
2015-12-26 - club - BBL - male - 897711 - Perth Scorchers vs Brisbane Heat
2015-12-27 - club - BBL - male - 897713 - Sydney Sixers vs Melbourne Stars
2015-12-28 - club - BBL - male - 897715 - Sydney Thunder vs Adelaide Strikers
2015-12-29 - club - BBL - male - 897717 - Brisbane Heat vs Hobart Hurricanes
2015-12-30 - club - BBL - male - 897719 - Melbourne Renegades vs Perth Scorchers
2015-12-31 - club - BBL - male - 897721 - Adelaide Strikers vs Sydney Sixers
2016-01-01 - club - BBL - male - 897723 - Hobart Hurricanes vs Sydney Thunder
2016-01-02 - club - BBL - male - 897725 - Melbourne Stars vs Melbourne Renegades
2016-01-02 - club - BBL - male - 897727 - Perth Scorchers vs Sydney Sixers
2016-01-03 - club - BBL - male - 897729 - Brisbane Heat vs Sydney Thunder
2016-01-04 - club - BBL - male - 897731 - Hobart Hurricanes vs Melbourne Renegades
2016-01-05 - club - BBL - male - 897733 - Adelaide Strikers vs Perth Scorchers
2016-01-06 - club - BBL - male - 897735 - Melbourne Stars vs Hobart Hurricanes
2016-01-07 - club - BBL - male - 897737 - Sydney Thunder vs Perth Scorchers
2016-01-08 - club - BBL - male - 897739 - Brisbane Heat vs Adelaide Strikers
2016-01-09 - club - BBL - male - 897741 - Melbourne Renegades vs Melbourne Stars
2016-01-10 - club - BBL - male - 897743 - Hobart Hurricanes vs Perth Scorchers
2016-01-10 - club - BBL - male - 897745 - Sydney Sixers vs Brisbane Heat
2016-01-11 - club - BBL - male - 897747 - Sydney Thunder vs Melbourne Renegades
2016-01-13 - club - BBL - male - 897749 - Adelaide Strikers vs Hobart Hurricanes
2016-01-14 - club - BBL - male - 897751 - Melbourne Stars vs Brisbane Heat
2016-01-16 - club - BBL - male - 897753 - Sydney Sixers vs Sydney Thunder
2016-01-18 - club - BBL - male - 897757 - Melbourne Renegades vs Adelaide Strikers
2016-01-21 - club - BBL - male - 897759 - Adelaide Strikers vs Sydney Thunder
2016-01-22 - club - BBL - male - 897761 - Melbourne Stars vs Perth Scorchers
2016-01-24 - club - BBL - male - 897763 - Melbourne Stars vs Sydney Thunder

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
